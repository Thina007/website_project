<?php
$db = mysqli_connect('localhost' , 'id15445415_root','4e_[|6QL3~5#b7E','id15445415_learning');

if(isset($_POST['register'])){
	$username=$_POST['username'];
	$password= $_POST['password'];

	$query = " SELECT * FROM user where username ='$username'";
	$result = mysqli_query($db,$query);
	if(mysqli_num_rows($result)==1){
		$record=mysqli_fetch_array($result);


		$id=$record[0];
      		if($password ==$record[4]){
				header("location: main page.php");
		
				session_start();
		   		$_SESSION['id']=$id;
				
	  		}else{
				echo " <script> alert('Your password is incorrect')</script>";
			}
      
	}else{
		echo "<script> alert ('Your userid is invalide')</script>";
	}

}


?>


<!DOCTYPE html>
<html>
<style type="text/css">
*{
	margin: 0px;
	padding: 0px;
	margin-left: 30px;
}
body{
	font-size: 20px;
	background-color:lightgray;
	
	
}
.header{
	width: 40%;
	margin-left: 90px;
	color: white;
	font-size: 12px;
	background:#5F9EA0;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;

}	


.loginform{
	margin-left: 40px;
	margin: 10px 0px 10px 0px;
}
.loginform label{
	display: block;
	color: black;
	margin-left: 200px;
	margin: 3px;
}
.btn{
	margin-left: 150px;
	font-family:sans-serif;
	font-weight: bolder;
	padding: 5px;
	border-radius: 12px;
}
.loginform input{
	height: 20px;
	width: 170px;
	padding: 5px 10px;
	font-size: 10px;
	border-radius: 5px;
	border:1px solid gray;
}
@media screen and (max-device-width: 360px){
 .form{
 	width: 1000px;
 	background-color: pink;
 	margin-left:0px;
    margin-top:0px;

 }	
 .header{
 	width: 100px;
 }
}


</style>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Form</title>
</head>

 
 	<div class="header">
       <h2>Login Form</h2>
    </div><br>
    <div class="loginform">
    <form   method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
         <body>
	      <label> User Name</label>
	      <input type="text" name="username" placeholder="Enter User Name" required>

	       <label> Password</label>
	       <input type="password" id="psw" name="password" placeholder="Enter User Password" required>

	   </body>
	   
	   	
	   </div>
	   <div >
	   	  <button type="submit" name="register" class="btn">Login</button><br>

	   </div>
	   <br> <p>I am  not a member ?<a href="server.php">Register</a></p>
 
    </form>     
</html>