<?php


$db = mysqli_connect('localhost' , 'id15445415_root','4e_[|6QL3~5#b7E','id15445415_learning');

session_start();
	$id=$_SESSION['thina'];



$query = " SELECT * FROM user where id ='$id'";
$result = mysqli_query($db,$query);
if(mysqli_num_rows($result)==1){
	$record=mysqli_fetch_array($result);

      
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>PROFILE</title>
</head>
<body>
<h1 class="profile">MY PROFILE</h1>

<div class="class">
<div class="container">
        <label for="name" class="label">NAME:</label><br><br>
        <input type="text" class="input" name="name" value="<?php echo $record[1] ?>" disabled><br><br><br><br>
        <label for="regno" class="label" >EMAIL:</label><br><br>
        <input type="text" class="input" name="regno" value="<?php echo $record[2] ?>" disabled><br><br><br><br>
        <label for="topic" class="label" >PHONE NUMBER:</label><br><br>
        <input type="text" class="input" name="topic" value="<?php echo $record[3] ?>" disabled><br>
       
</div>

</div>

</body>
<style type="text/css">
*{
     margin-top:50px;
    font-size:40px;
    background-color:palegreen;
}
.profile{
    color:red;
    font-family:serif;
    font-weight: bolder;
    text-align:center;
}
.container{
   
    float: left;
    font-family: sans-serif;
    font-weight: bolder;
    margin-left: 100px;
    margin-top: 100px;
}

.container input{
    text-align:center;
    font-family: sans-serif;
    color: blue;
    border: 2px solid white;
    font-weight: bolder; 
    padding: 20px;
}

</style>

</html>