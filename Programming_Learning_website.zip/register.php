<?php 
$db = mysqli_connect('localhost' , 'id15445415_root','4e_[|6QL3~5#b7E','id15445415_learning');

if(isset($_POST['register'])){
	$username=$_POST['username'];
	$email= $_POST['email'];
	$phonenumber=$_POST['phonenumber'];
	$password= $_POST['password'];



	$query="INSERT INTO user(username, email, phonenumber, password,userid)
	 VALUES ('$username','$email','$phonenumber','$password','NULL')";
	$result=mysqli_query($db, $query);
	if($result){
		echo"<script>alert('Registration successfully') </script>";
	      echo '<script> window.location="server.php"</script>';
	}
	else{
		echo"<scrpit> alert ('Already Have This User Name please Try in Different User Name')</script>";
	}


} 

?>
<!DOCTYPE html>
<html>
<style type="text/css">
*{
	margin: 0px;
	padding: 0px;
	margin-left: 30px;
}
body{
	font-size: 20px;
	background-color:lightgrey;
	
}
.header{
	width: 60%;
	margin-top:50px;
	margin-left: 60px;
	color: white;
	font-size: 20px;
	background:#5F9EA0;
	border-bottom: none;
	border-radius: 10px ;

}
.header h2{
    width:50%;
}


.loginform{
	margin-left: 40px;
	margin: 10px 0px 10px 0px;
}
.loginform label{
	display: block;
	color: black;
	margin-left:200px;
	margin: 3px;
}
.btn{
	margin-left: 210px;
	font-family:sans-serif;
	font-weight: bolder;
	padding: 10px;
	border-radius: 5px;
}
.loginform input{
	height: 35px;
	width: 230px;
	padding: 5px 10px;
	font-size: 18px;
	border-radius: 5px;
	border:1px solid gray;
}
@media screen and (max-device-width: 360px){
 .form{
 	width: 1000px;
 	background-color: pink;
 	margin-left:0px;
    margin-top:0px;

 }	
 .header{
 	width: 100px;
 }
}

</style>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registration Form</title>
</head>

 
 	<div class="header">
       <h2>Registration Form</h2>
    </div><br>
    <div class="loginform">
    <form   method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
         <body>
	      <label> User name</label>
	      <input type="text" name="username" placeholder="Enter User Name" required>
	  

	      <label> Email</label>
	      <input type="text" name="email" id="email" placeholder="Enter User Email" required>
  

        
	       <label> Phone Number</label>
	       <input type="number" name="phonenumber" placeholder="Enter user Phone Number" required>
	


	       <label> Password</label>
	       <input type="password" id="psw" name="password" placeholder="Enter User Password" required>

	   </body>
	   
	   	
	   
	   <div >
	   	  <button type="submit" name="register" class="btn" >Register</button><br>

	   </div>
	   <br> <p>Alredy a member ?<a href="server.php">sign in</a></p>
 
    </form>  
    <br><br><br><a href="index.html" style=" color:green;  font-size: 30px;margin-left: 0px;color:red;margin-top: 80px;font-family: sans-serif;text-decoration:none;font-weight: bolder;background-color:aqua;border-radius: 12px;border:3px solid gray;"> < < BACK</a>
</div><br><br>
</html>