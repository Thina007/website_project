<?php
 
$db = mysqli_connect('localhost' , 'id15445415_root','4e_[|6QL3~5#b7E','id15445415_learning');

if(isset($_POST['submit'])){
  $userid=$_POST['userid'];
  $email= $_POST['email'];
 

  $query="INSERT INTO stipend(userid, email)
   VALUES ('$userid','$email')";
  $result=mysqli_query($db, $query);
  if($result){
    echo("You Request submit successfull");
  }
  else{
    echo("You Request submit failed");
  }


} 

?>










<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

.container input{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 5px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  border-radius:2px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}
p{
  font-weight: bolder;
  color: red;
  font-family: sans-serif;
}



.container {
  padding: 16px;
}
</style>
</head>
<body>

<h2>Stipend Requiest Form</h2>
<p>NOTE: Pleace Don't use This Option Before 30 Day's of Your Study's othewise Your Id Will be Blocked....!</p>
<form  method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

  <div class="container">
    <label><b>User id</b></label>
    <input type="text" placeholder="Enter User id" name="userid" required>
  </div>


    <div class="container">
    <label><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" required>
  </div>
        
    <button type="submit" name="submit">Submit</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

</form>  
</body>
<br><br><br><a href="main page.php" style=" color:green;  font-size: 30px;margin-left: 5px;color:red;margin-top: 80px;font-family: sans-serif;text-decoration:none;font-weight: bolder;background-color:aqua;border-radius: 12px;border:5px solid gray;"> < < BACK</a>
</div><br><br>
</html>
