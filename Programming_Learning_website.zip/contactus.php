<?php
 

$db = mysqli_connect('localhost' , 'id15445415_root','4e_[|6QL3~5#b7E','id15445415_learning');

if(isset($_POST['submit'])){
 $userid= $_POST['userid'];
  $email= $_POST['email'];
  $message= $_POST['message'];
 

  $query="INSERT INTO contact(userid, email,message)
   VALUES ('$userid','$email','$message')";
  $result=mysqli_query($db, $query);
  if($result){
    echo("You Request submit successfull");
  }
  else{
    echo("You Request submit Failed");
  }
} 
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<style type="text/css">

.contact{
	float: left;
	background-color:#f2f2f2;
	border-radius: 5px;
	padding: 20px;
}
.contact  input{
	padding: 10px;
	border-right:2px solid #333;
	margin: 10px;
	width: 320px;
	border-bottom: 2px solid #333;
	margin-top: 10px;

}
.contact label{
	text-align: center;
	font-size: 15px;
	font-weight: bolder;
	font-family: sans-serif;
}

.btn{
	background-color: #4CAF50;
	margin-left: 320px;
	color: white;
	margin-top:20px;
	margin-bottom: 10px;
	border-radius: 3px;
	padding: 10px;
	width: 80px;

}
.fa{
    text-align:center;
    text-decoration:none;
    margin:5px 2px;
    border-radius:50%;
    padding:20px;
    width:20px;
   
}
.fa:hover{
	opacity: 0.7;
	
}

.fa-facebook{
    margin-left:70px;
    background-color:#3B5998;
	color:white;
	
	
}

.fa-instagram{
    margin-left:20px;
    background-color:#125688;
    color:white;
   

}

.fa-youtube{
    margin-left:20px;
    background-color:#bb0000;
     color:white;

}



</style>




<body>
<form method="post"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">


	<h2>Contact Us</h2>
	<div class="media">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


	<a href="#" class="fa fa-facebook"></a>
	<a href="#" class="fa fa-instagram"></a>
	<a href="#" class="fa fa-youtube"></a>
   </div>

  <div class="contact">
  	<h3>Sent Message</h3><br>

     <label>User ID</label><br>
  	<input type="text" name="userid"  required="required"><br>
  	 <label>Email</label><br>
  	<input type="email" name="email" required="required"><br>
  	 <label>Your Message</label><br>
  	<b><textarea type="text" name="message" required="required" placeholder="Write Something...." style="height: 100px ;width: 350px; resize: none;"></textarea><br></b>
	
</div>
</form><br>
<br><input type="submit" class="btn" name="submit" value="SENT"><br>
</body>
<a href="index.html" style=" color:green;  font-size: 30px;margin-left: 0px;color:red;margin-top: 80px;font-family: sans-serif;text-decoration:none;font-weight: bolder;background-color:aqua;border-radius: 12px;border:3px solid gray;"> < < BACK</a>

</html>